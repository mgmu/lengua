package fr.uparis.lengua

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log

class NotificationDismissReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        Log.d("logLengua", "DISSSMISSED NOTIFICATION")
        TODO("NotificationDismissReceiver.onReceive() is not implemented")
    }
}